package com.cookandroid.lottoNote;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;

public class Randomnum extends Activity {

    HashSet<String> lottoSet = new HashSet<String>();
    ArrayList<String> arrList = new ArrayList<String>();
    int[] lottoList = {0,0,0,0,0,0};
    String[] lottosList = {"","","","","",""};
    String str = "";

    static int a;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_randomnum);


        Button btnnext = findViewById(R.id.btnNext2);
        Button btnpre = findViewById(R.id.btnPre2);
        Button btnexit = findViewById(R.id.btnExit2);
        Button btnresult = findViewById(R.id.lottoresult);
        TextView lottonum1 = findViewById(R.id.lottonum);

        a = 0;

        while (lottoSet.size() < 7) {
            int num = (int) (Math.random() * 45);
            Log.d("Main", String.valueOf(num));
            if (num != 0) {
                lottoSet.add(num + "");
            }
        }

        arrList.addAll(lottoSet);

        for (int i = 0; i < arrList.size(); i++) {
            if (i < 6) {
                lottoList[i] = Integer.parseInt((arrList.get(i)));
                lottosList[i] = (arrList.get(i));
                str += lottoList[i] + " ";
            }
        }
        lottoSet.clear();
        arrList.clear();

        lottonum1.setText(lottosList[0]);

        btnpre.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(a > 0) {
                    a -= 1;
                    //setnum(lottoList[a]);
                    lottonum1.setText(lottosList[a]);

                }
            }
        });

        btnnext.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(a < 5) {
                    a += 1;
                    //setnum(lottoList[a]);
                    lottonum1.setText(lottosList[a]);

                }
            }
        });

        btnresult.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent lottointent = new Intent(Randomnum.this, Lottoresult.class);
                lottointent.putExtra("lottoresult",str);
                startActivity(lottointent);
            }
        });

        btnexit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });


    }
    /*public void setnum(int str){
        GradientDrawable drawable = (GradientDrawable) ContextCompat.getDrawable(this, R.drawable.shape);
        if(str > 0 && str < 11){
            drawable.setStroke(10,Color.YELLOW);
        }else if(str > 10 && str < 21){
            drawable.setStroke(10,Color.BLUE);
        }else if(str > 20 && str < 31){
            drawable.setStroke(10,Color.RED);
        }else if(str > 30 && str < 41){
            drawable.setColor();
        }else if(str > 40 && str < 46){
            drawable.setStroke(10,Color.GREEN);
        }
    }*/
}