/*
package com.cookandroid.andvoca;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.AttributeSet;

public class studydata2 {
    static Context mContext1;

    MyDBHelper1 m_helper;
    //FileTable mFile1;

    public studydata2(Context context1, AttributeSet attrs1) {

        mContext1 = context1;
        initAll1();
    }

    public void initAll1() {
        m_helper = new MyDBHelper1(mContext1, "testforeng.db", null, 1);

       // mFile1 = new FileTable();

    }

    class MyDBHelper1 extends SQLiteOpenHelper {

        public MyDBHelper1(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }


        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE englishWordTable (_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    " eWord TEXT, kWord TEXT);");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            db.execSQL("DROP TABLE IF EXISTS englishWordTable");
            onCreate(db);
        }
    }
}*/
