package com.cookandroid.lottoNote;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class Manual extends Activity {

    static int a;
    static int b;

    static String[] meantxt;
    String[] wordtxt = {"로또","즉석복권"};
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual);

        Button btnpre = findViewById(R.id.btnPre1);
        Button btnnext = findViewById(R.id.btnNext1);

        Button btnexit = findViewById(R.id.btnExit1);

        TextView word = findViewById(R.id.word);



        InputStream fi;
        fi = getResources().openRawResource(R.raw.howlotto);
        TextView edittto = findViewById(R.id.editto);

        try {

            byte[] data = new byte[fi.available()];
            fi.read(data);
            fi.close();

            String s = new String(data, "UTF-8");
            meantxt = s.split("/");
            edittto.setText(meantxt[0]);
            word.setText(wordtxt[0]);
        }
        catch (IOException e) {
        }

        a = 0;
        b = 0;

        btnpre.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(a > 0) {
                    a -= 1;
                    edittto.setText(meantxt[a]);
                    b -= 1;
                    word.setText(wordtxt[b]);
                }
            }
        });

        btnnext.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(a < 1) {
                    a += 1;
                    edittto.setText(meantxt[a]);
                    b += 1;
                    word.setText(wordtxt[b]);
                }
            }
        });


        btnexit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });

    }
}