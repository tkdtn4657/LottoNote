package com.cookandroid.lottoNote;

/*
public class mynote extends Activity {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mynote);

        TextView wnote = findViewById(R.id.wnote);
        TextView mnote = findViewById(R.id.mnote);
        String rnote = "";
        Intent inIntent = getIntent();
        String strr = inIntent.getStringExtra("Mnote");
         String msplit[][] = new String[100][2];
        String strrr = "\n";

        String tmp[] = strr.split(",");
        String s;

        for(int i = 0; i< tmp.length; i++ ) {
            strrr += tmp[i] + "\n";
        }


            String note[][] = new String[100][2];

            wnote.setText(inIntent.getStringExtra("Wnote"));
            mnote.setText(strrr);
        */
/*for()
        note[i][j] = inIntent.getStringExtra("Wnote");
        note[i][j] = inIntent.getStringExtra("Mnote");*//*


        }
    }

*/
