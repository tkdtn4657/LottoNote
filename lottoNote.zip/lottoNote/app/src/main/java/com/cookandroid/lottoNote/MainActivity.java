package com.cookandroid.lottoNote;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    Button button;
    TextView textView;
    String lotto_No;
    String[] lotto_number = {"drwtNo1", "drwtNo2", "drwtNo3", "drwtNo4", "drwtNo5", "drwtNo6", "bnusNo"};
    JsonObject jsonObject;
    RequestQueue requestQueue;
    TextView text2, text3;
    Button smallerBtn, biggerBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);
        setTitle("LottoNotes");

        findViewById(R.id.main1).setOnClickListener(myClick);
        findViewById(R.id.main2).setOnClickListener(myClick);
        findViewById(R.id.main3).setOnClickListener(myClick);

        smallerBtn = findViewById(R.id.smaller);
        biggerBtn = findViewById(R.id.bigger);

        TabHost tabHost = findViewById(R.id.tabHost);
        tabHost.setup();

        TabHost.TabSpec modiColor = tabHost.newTabSpec("menu").setIndicator("주기능");
        modiColor.setContent(R.id.modiColor);
        tabHost.addTab(modiColor);

        TabHost.TabSpec modiSize = tabHost.newTabSpec("lottoresult").setIndicator("지난 회차");
        modiSize.setContent(R.id.modiSize);
        tabHost.addTab(modiSize);


        tabHost.setCurrentTab(0);

        editText = findViewById(R.id.editTextc);
        textView = findViewById(R.id.textViewc);
        button = findViewById(R.id.buttonc);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestLottoNumber(); } }); if (requestQueue == null)
        { requestQueue = Volley.newRequestQueue(getApplicationContext()); }
        

        biggerBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                float size = textView.getTextSize();
                textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, size+10);
            }
        });

        smallerBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                float size = textView.getTextSize();
                textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, size-10);
            }
        });

    }

    public void requestLottoNumber() { lotto_No = editText.getText().toString();
        if (lotto_No.equals("")) { Toast.makeText(this, "로또 회차 번호를 입력해주세요", Toast.LENGTH_SHORT).show(); return; }
        String url = "https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo=" + lotto_No;
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) { jsonObject = (JsonObject) JsonParser.parseString(response);
                String str = lotto_No + "회차 당첨번호 : ";
                for (int i = 0; i < lotto_number.length - 1; i++) {
                    str += jsonObject.get(lotto_number[i]) + ", ";
                }
                str += " bonus: " + jsonObject.get(lotto_number[lotto_number.length-1]);
                textView.setText(str);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) { } })
        { // Header나 요청 parameter를 재정의 할 수 있다.
            // GET방식에서는 url에 parameter가 함께 있어 불필요, POST 방식에서 사용
            protected Map<String, String> getParams() throws AuthFailureError {Map<String, String> params = new HashMap<>();
                return params;
            }
        };
        request.setShouldCache(false); // 캐싱하지 말고 매번 받은것은 다시 보여주도록 설정
        requestQueue.add(request);
    }

    Button.OnClickListener myClick = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {

                case R.id.main1:
                    Toast.makeText(getApplicationContext(),"복권 사이트",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this, Boksite.class));
                    break;

                case R.id.main2:
                    Toast.makeText(getApplicationContext(),"설명서",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this, Manual.class));
                    break;

                case R.id.main3:
                    Toast.makeText(getApplicationContext(),"메모",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this, Randomnum.class));
                    break;
                //exit
                case R.id.main4:
                    Toast.makeText(getApplicationContext(),"감사합니다",Toast.LENGTH_SHORT).show();
                    finish();
                    break;
            }
        }
    };
}
