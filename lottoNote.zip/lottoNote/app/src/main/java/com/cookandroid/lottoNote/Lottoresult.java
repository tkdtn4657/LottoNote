package com.cookandroid.lottoNote;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Lottoresult extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lottoresult);

        Button exitR = findViewById(R.id.resultexit);
        TextView result = findViewById(R.id.lottoNresult);
        Intent inIntent = getIntent();
        String str = inIntent.getStringExtra("lottoresult");
        result.setText(str);

        exitR.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                finish();
            }
        });

    }
}
