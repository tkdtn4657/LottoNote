/*
package com.cookandroid.andvoca;

import java.io.IOException;
import java.io.InputStream;

public class voca1 {
    public static String questionNum[][] = new String[100][2];

    public voca1(String str) {
        String tmp[] = str.split("/");
        String s;

        for (int i = 0; i < tmp.length; i++) {

            s = tmp[i];
            String tmp2[] = s.split(":");

            for(int j = 0; j < 2; j++){
                //tmp2[j]=tmp2[j].trim();
                questionNum[i][j]=tmp2[j];

            }
        }
    }

    public String getname(int a, int b){
        return  this.questionNum[a][b];
    }
}
*/
